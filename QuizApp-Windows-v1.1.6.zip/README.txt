Quiz App for Windows

Huong dan:
1. Giai nen file ZIP.
2. Chay QuizApp.exe.
3. Neu Windows hien SmartScreen, chon More info -> Run anyway neu ban tin tuong nguon tai.

Huong dan nhanh trong app:
- Sau khi dang nhap, bam nut Huong dan o thanh ben trai.
- Admin se thay huong dan quan ly hoc sinh, giao vien, de thi va ket qua.
- Giao vien se thay huong dan tao cau hoi, import CSV, tao de thi va xem ket qua.
- Hoc sinh se thay huong dan dang ki, lam bai, nop bai va xem diem.

Luu y:
- Day la ung dung C++ Win32 ket noi Firebase Firestore.
- Goi nay khong chua Firebase serviceAccountKey.json.
- Khong xoa cac file DLL di kem vi app can chung de chay tren may khac.
- Can co Internet de dang ki, dang nhap va ghi du lieu len Firebase.
- De thi chi lam duoc sau thoi gian mo de, va app se tu dong nop bai khi het gio.
- Neu dang ki that bai, thu mo trinh duyet va truy cap https://firestore.googleapis.com de kiem tra may co vao duoc dich vu Google API khong.
- Admin co the quan ly hoc sinh/giao vien bang bang, xoa tai khoan va chuyen lop/phu trach.
- Admin co the dat lai mat khau cho hoc sinh/giao vien khi nguoi dung quen mat khau.
- Nguoi dung co the cap nhat thong tin ca nhan, email va mat khau; sau khi luu se can dang nhap lai.
- Giao vien co the nhap cau hoi hang loat bang cach chon file CSV tu may, dan CSV truc tiep hoac tai URL CSV cong khai.
- Khi import CSV, nhap Mon hoc/Chu de trong app mot lan; file CSV chi can cac cot: content, optionA, optionB, optionC, optionD, correctAnswer.
- File sample_questions.csv la mau de giao vien mo bang Excel/Google Sheets va sua lai cau hoi.
- Giao vien co the dinh kem file de goc .docx/.pdf/.jpg/.jpeg/.png khi tao de thi, hoac dan link file de cong khai.
- Neu tao de tu file goc, co the de trong Ma cau hoi va nhap Dap an file de theo dang: A C B B A hoac ACBBA.
- App se tao phieu tra loi theo so dap an da nhap va cham diem theo dap an mau do.
- Ban hien tai ho tro toi da 60 cau cho de file goc.
- Neu chon file tu may, app se copy file vao thu muc exam_files nam canh QuizApp.exe tren may dang tao de.
- Neu hoc sinh lam bai tren may khac, nen dung link file de cong khai vi du Google Drive/OneDrive/Firebase Storage public link de tat ca may deu mo duoc.
- Khi vao bai file goc, hoc sinh bam Mo file de de xem noi dung roi chon dap an theo so cau trong app.
